// TEST-ONLY: drive dsh-dgx-audio 0.4.0 activation (TASK_CONTRACT 0.2 §C) from E2E scripts, the way the
// model-library host half would, so the shared audio UI's gate can be exercised against the real host.
export const name = 'dsh-e2e-activation'
export const inject = ['dshAudio', 'connection']

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })

export function apply(ctx) {
  ctx.effect(() => ctx.connection.fetch.register({
    path: '/api/e2e-activation',
    methods: ['POST', 'GET'],
    requestBody: 'buffered',
    fetch: async (request) => {
      try {
        if (request.method === 'GET') return json(200, { ok: true, busy: ctx.dshAudio.busy(), contractVersion: ctx.dshAudio.contractVersion })
        const body = await request.json()
        const next = ctx.dshAudio.setActivation(body.provider, body.model, { state: body.state, detail: body.detail, progress: body.progress })
        return json(200, { ok: true, activation: next })
      } catch (error) {
        return json(400, { ok: false, error: { code: 'BAD_REQUEST', message: String(error?.message ?? error) } })
      }
    },
  }), 'e2e-activation: route')
}
